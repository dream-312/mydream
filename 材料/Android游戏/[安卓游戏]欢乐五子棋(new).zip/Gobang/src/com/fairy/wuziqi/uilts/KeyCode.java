package com.fairy.wuziqi.uilts;

public class KeyCode {
	public static int GRID_SIZE = 0;
}
