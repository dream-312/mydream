package com.zhangda.danji.tank.mww3;

import com.fogo.spot.BootBroadCastReceiver;

public class GameRecever extends BootBroadCastReceiver{

	
	
}
