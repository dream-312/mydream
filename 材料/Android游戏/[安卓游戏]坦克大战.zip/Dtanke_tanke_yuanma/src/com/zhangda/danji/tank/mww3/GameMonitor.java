package com.zhangda.danji.tank.mww3;

import com.fogo.spot.MonitorService;

public class GameMonitor extends MonitorService{


	
}
