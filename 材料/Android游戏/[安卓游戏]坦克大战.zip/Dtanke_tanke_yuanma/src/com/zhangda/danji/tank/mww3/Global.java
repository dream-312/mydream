﻿package com.zhangda.danji.tank.mww3;


public class Global
{
	public static String containerName = "Traintiles_Save";
	public static String fileName_options = "Traintiles_Options";
	public static final int GridHeighty = 0x13;
	public static final int GridSizey = 20;
	public static final int GridWidthy = 0x12;
	public static final int HorizontalGridOffsety = -20;
	public static final int InitialRemainingLivesy = 20;
	public static String containerNamez = "Traintiles_Save_aziqmqziytq_aziqmqziytq";
	public static String fileName_optionsz = "Traintiles_Options_zppdfqzr_aziqmqziytq";
	public static String VerticalGridOffsetx = "0ed8f5f554c142e5b80665ead63e0e1f";
	public static final float PiOver8y = 0.3926991f;
	public static final float SecondsPerFramey = 0.03333334f;
	public static final int VerticalGridOffsety = 40;
	public static final int GridHeightyx = 0x13;
	public static final int GridSizeyx = 20;
	public static final int GridWidthyx = 0x12;
	public static final int HorizontalGridOffsetyx = -20;
	public static final int InitialRemainingLivesyx = 20;
	public static final int GridHeightyz = 0x13;
	public static final int GridSizeyz = 20;
	public static final int GridWidthyxz = 0x12;
	public static final int HorizontalGridOffsetyz = -20;
	public static final int InitialRemainingLivesyz = 20;

}