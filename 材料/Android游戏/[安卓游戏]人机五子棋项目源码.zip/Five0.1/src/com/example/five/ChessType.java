package com.example.five;

enum ChessType {
	NONE,
	WHITE,
	BLACK
}
