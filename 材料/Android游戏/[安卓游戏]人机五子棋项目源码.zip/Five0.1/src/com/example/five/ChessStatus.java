package com.example.five;

public enum ChessStatus {
	ALIVE,
	DIED,
	HALFALIVE
}
