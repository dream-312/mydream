package com.example.five;

public class Screen {
	public static int screenWidth;
	public static int screenHeight;

	public Screen(int screenWidth, int screenHeight) {
		this.screenWidth = screenWidth;
		this.screenHeight = screenHeight;
	}
}
