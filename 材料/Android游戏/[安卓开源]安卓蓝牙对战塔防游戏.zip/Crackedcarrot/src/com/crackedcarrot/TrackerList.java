package com.crackedcarrot;

public class TrackerList {
	public TrackerData data;
	public TrackerList next;

	public TrackerList() {
	}

}
