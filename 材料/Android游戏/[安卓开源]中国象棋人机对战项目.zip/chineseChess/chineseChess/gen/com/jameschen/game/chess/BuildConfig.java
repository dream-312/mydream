/** Automatically generated file. DO NOT MODIFY */
package com.jameschen.game.chess;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}