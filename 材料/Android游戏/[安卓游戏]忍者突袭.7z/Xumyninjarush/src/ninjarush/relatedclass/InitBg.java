package ninjarush.relatedclass;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class InitBg {
	private Bitmap backgroundBitmap;
	private int tx,ty;
	public InitBg(){
		
	}
}
