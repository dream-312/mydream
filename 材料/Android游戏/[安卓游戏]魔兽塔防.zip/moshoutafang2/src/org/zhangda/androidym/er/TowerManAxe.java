﻿package org.zhangda.androidym.er;

public class TowerManAxe extends TowerMan
{
	public TowerManAxe(MainGame game, Tower tower)
	{
		super(game, "assets/tower_axeman.png", tower, 0x20, 0x20);
	}
}