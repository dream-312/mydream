﻿package org.zhangda.androidym.er;

public class TowerButtonSpear extends TowerButton
{
	public TowerButtonSpear(MainGame game)
	{
		super(game, TowerType.Spear);
		super.setTowerPrice (15);
	}
}