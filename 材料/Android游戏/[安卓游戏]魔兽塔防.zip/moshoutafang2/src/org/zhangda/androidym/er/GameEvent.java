package org.zhangda.androidym.er;

public interface GameEvent{
	public void invoke(MenuEntry comp);
}