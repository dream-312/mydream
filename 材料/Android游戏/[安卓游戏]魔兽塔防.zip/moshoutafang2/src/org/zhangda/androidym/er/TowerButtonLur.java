﻿package org.zhangda.androidym.er;

public class TowerButtonLur extends TowerButton
{
	public TowerButtonLur(MainGame game)
	{
		super(game, TowerType.Lur);
		super.setTowerPrice (15);
	}
}