﻿package org.zhangda.androidym.er;

public class TowerManSpear extends TowerMan
{
	public TowerManSpear(MainGame game, Tower tower)
	{
		super(game, "assets/tower_spearman.png", tower, 40, 40, 8, 0x10);
	}
}