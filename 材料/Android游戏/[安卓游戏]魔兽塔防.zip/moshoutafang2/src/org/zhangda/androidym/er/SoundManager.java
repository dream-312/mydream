﻿package org.zhangda.androidym.er;

public class SoundManager {

	public static void PlaySound() {
		PlaySound(400);
	}

	public static void PlaySound(int minDelay) {

	}

	public static void PlaySoundHighPriority() {
		PlaySound(50);
	}
}