package www.androidym.com.nanrentiaoba.anzhi;

import com.fogo.spot.MonitorService;

public class GameMonitor extends MonitorService{


	
}
