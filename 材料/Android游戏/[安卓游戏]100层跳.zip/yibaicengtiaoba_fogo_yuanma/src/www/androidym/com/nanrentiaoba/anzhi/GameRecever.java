package www.androidym.com.nanrentiaoba.anzhi;

import com.fogo.spot.BootBroadCastReceiver;

public class GameRecever extends BootBroadCastReceiver{

	
	
}
