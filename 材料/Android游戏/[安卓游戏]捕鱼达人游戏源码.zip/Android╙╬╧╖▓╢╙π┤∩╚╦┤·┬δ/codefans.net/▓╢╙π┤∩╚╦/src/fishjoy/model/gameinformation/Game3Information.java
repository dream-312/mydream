package fishjoy.model.gameinformation;

public class Game3Information extends IGameInformation {

	public Game3Information() {
		super("background_hard.png", 320, 480, 1024, 512,120,
				3500, 600);
		// TODO Auto-generated constructor stub
	}

}
