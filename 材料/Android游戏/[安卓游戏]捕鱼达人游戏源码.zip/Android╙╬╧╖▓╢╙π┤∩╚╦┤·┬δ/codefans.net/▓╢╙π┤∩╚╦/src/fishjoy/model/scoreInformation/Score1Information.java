package fishjoy.model.scoreInformation;

public class Score1Information extends IScoreInformation {

	public Score1Information() {
		super("4.png", 49, 30, 64, 256, 1, 6);
		// TODO Auto-generated constructor stub
	}
}
