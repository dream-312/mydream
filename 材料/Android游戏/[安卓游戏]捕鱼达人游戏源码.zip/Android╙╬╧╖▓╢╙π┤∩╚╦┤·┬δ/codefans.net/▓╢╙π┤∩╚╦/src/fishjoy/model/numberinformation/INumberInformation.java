package fishjoy.model.numberinformation;

import fishjoy.model.IEntityInformation;

public class INumberInformation extends IEntityInformation {

	public INumberInformation(String path ) {
		super(path, 20, 25, 32, 64);
		// TODO Auto-generated constructor stub
	}

}
