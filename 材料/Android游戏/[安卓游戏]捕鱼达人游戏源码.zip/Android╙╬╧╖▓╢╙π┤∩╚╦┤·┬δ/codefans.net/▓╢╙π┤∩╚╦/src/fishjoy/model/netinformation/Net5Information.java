package fishjoy.model.netinformation;

public class Net5Information extends INetInformation {

	public Net5Information() {
		super("net5.png", 172, 800, 256, 1024);
	}

}
