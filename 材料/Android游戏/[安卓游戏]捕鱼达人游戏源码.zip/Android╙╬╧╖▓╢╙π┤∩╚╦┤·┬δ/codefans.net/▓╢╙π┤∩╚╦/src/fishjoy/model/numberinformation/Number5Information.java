package fishjoy.model.numberinformation;

public class Number5Information extends INumberInformation {

	public Number5Information() {
		super("N5.png");
		// TODO Auto-generated constructor stub
	}

}
