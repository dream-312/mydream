package fishjoy.model.netinformation;

public class Net4Information extends INetInformation {

	public Net4Information() {
		super("net4.png", 172, 800, 256, 1024);
		// TODO Auto-generated constructor stub
	}

}
