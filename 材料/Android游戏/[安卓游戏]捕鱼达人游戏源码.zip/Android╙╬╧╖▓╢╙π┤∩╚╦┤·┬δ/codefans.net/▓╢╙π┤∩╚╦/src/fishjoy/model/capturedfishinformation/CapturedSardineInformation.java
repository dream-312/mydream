package fishjoy.model.capturedfishinformation;

public class CapturedSardineInformation extends ICapturedFishInformation {

	public CapturedSardineInformation() {
		super("sardine_2.png", 33, 22, 64, 256, 1, 5,0);
		// TODO Auto-generated constructor stub
	}

}
