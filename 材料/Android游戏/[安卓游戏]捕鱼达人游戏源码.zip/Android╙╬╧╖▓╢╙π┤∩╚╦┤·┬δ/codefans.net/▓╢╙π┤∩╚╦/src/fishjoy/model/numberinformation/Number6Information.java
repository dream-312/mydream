package fishjoy.model.numberinformation;

public class Number6Information extends INumberInformation {

	public Number6Information() {
		super("N6.png");
		// TODO Auto-generated constructor stub
	}

}
