package fishjoy.model.numberinformation;

public class Number0Information extends INumberInformation {

	public Number0Information() {
		super("N0.png");
		// TODO Auto-generated constructor stub
	}

}
