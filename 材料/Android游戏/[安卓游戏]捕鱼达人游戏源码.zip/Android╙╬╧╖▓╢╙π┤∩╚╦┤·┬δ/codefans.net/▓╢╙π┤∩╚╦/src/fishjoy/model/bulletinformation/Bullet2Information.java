package fishjoy.model.bulletinformation;

import fishjoy.model.netinformation.Net2Information;
//Download by http://www.codefans.net
public class Bullet2Information extends IBulletInformation {

	public Bullet2Information() {
		super("B2.png",18,27,32,32, new Net2Information(), 80, 400, 100);
		// TODO Auto-generated constructor stub
	}

}
