package fishjoy.model.bulletinformation;

import fishjoy.model.netinformation.Net5Information;
//Download by http://www.codefans.net
public class Bullet5Information extends IBulletInformation {

	public Bullet5Information() {
		super("B5.png",18,39,32,64, new Net5Information(), 0, 480, 0);
		// TODO Auto-generated constructor stub
	}
}
