package fishjoy.model.capturedfishinformation;

public class CapturedSharkInformation extends ICapturedFishInformation {

	public CapturedSharkInformation() {
		super("shark_2.png", 148,81, 128, 256, 1, 4,0);
		// TODO Auto-generated constructor stub
	}

}
