package fishjoy.model.netinformation;

public class Net3Information extends INetInformation {

	public Net3Information() {
		super("net3.png", 172, 800,256, 1024);
		// TODO Auto-generated constructor stub
	}

}
