package fishjoy.model.gameinformation;

public class Game2Information extends IGameInformation {

	public Game2Information() {
		super("background_common.png", 320, 480, 1024, 512, 90,
				2000, 600);
		// TODO Auto-generated constructor stub
	}

}
