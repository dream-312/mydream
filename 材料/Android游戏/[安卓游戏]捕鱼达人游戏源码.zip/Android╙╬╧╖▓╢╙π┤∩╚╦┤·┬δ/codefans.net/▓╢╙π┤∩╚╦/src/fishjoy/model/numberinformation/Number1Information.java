package fishjoy.model.numberinformation;

public class Number1Information extends INumberInformation {

	public Number1Information() {
		super("N1.png");
	}

}
