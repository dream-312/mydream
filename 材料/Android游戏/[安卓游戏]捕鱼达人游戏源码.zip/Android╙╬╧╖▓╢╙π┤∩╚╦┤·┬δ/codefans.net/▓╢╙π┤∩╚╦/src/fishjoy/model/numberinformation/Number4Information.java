package fishjoy.model.numberinformation;

public class Number4Information extends INumberInformation {

	public Number4Information() {
		super("N4.png");
		// TODO Auto-generated constructor stub
	}

}
