package fishjoy.model.numberinformation;

public class Number3Information extends INumberInformation {

	public Number3Information() {
		super("N3.png");
		// TODO Auto-generated constructor stub
	}

}
