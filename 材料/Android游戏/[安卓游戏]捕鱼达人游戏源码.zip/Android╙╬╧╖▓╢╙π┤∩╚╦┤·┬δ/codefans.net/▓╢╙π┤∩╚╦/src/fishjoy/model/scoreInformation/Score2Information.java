package fishjoy.model.scoreInformation;

public class Score2Information extends IScoreInformation {

	public Score2Information() {
		super("10.png",62,30,64, 256, 1, 6);
		// TODO Auto-generated constructor stub
	}

}
