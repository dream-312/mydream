package fishjoy.model.bulletinformation;
//Download by http://www.codefans.net
import fishjoy.model.netinformation.Net3Information;

public class Bullet3Information extends IBulletInformation {

	public Bullet3Information() {
		super("B3.png",19,34,32,64, new Net3Information(), 50, 430, 50);
		// TODO Auto-generated constructor stub
	}

}
