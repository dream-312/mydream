package fishjoy.model.scoreInformation;

public class Score4Information extends IScoreInformation {

	public Score4Information() {
		super("50.png", 59, 29, 64, 256, 1, 6);
		// TODO Auto-generated constructor stub
	}
}
