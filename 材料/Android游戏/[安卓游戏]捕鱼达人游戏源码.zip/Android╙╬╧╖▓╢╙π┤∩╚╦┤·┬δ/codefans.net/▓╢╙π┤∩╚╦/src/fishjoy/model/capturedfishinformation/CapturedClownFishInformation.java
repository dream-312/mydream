package fishjoy.model.capturedfishinformation;

public class CapturedClownFishInformation extends ICapturedFishInformation {

	public CapturedClownFishInformation() {
		super("clownfish_2.png", 50, 29, 64, 256, 1, 5,0);
		// TODO Auto-generated constructor stub
	}

}
