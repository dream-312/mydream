package fishjoy.model.numberinformation;

public class Number2Information extends INumberInformation {

	public Number2Information() {
		super("N2.png");
		// TODO Auto-generated constructor stub
	}

}
