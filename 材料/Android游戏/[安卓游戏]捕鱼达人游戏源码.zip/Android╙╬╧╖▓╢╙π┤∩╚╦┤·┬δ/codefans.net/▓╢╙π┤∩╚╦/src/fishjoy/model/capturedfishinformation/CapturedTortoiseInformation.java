package fishjoy.model.capturedfishinformation;

public class CapturedTortoiseInformation extends ICapturedFishInformation{

	public CapturedTortoiseInformation() {
		super("tortoise_2.png",93, 41, 128, 256, 1, 5,0);
		// TODO Auto-generated constructor stub
	}

}
