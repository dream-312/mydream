package fishjoy.model.scoreInformation;

public class Score5Information extends IScoreInformation {

	public Score5Information() {
		super("100.png", 80,30,64, 256, 1, 6);
		// TODO Auto-generated constructor stub
	}

}
