package fishjoy.control.game.factory;

public class UserFactory {

}
