package fishjoy.model.bulletinformation;

import fishjoy.model.netinformation.Net4Information;

public class Bullet4Information extends IBulletInformation {

	public Bullet4Information() {
		super("B4.png",20,34,32,64, new Net4Information(), 20, 460, 20);
		// TODO Auto-generated constructor stub
	}
}
