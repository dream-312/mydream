package fishjoy.model.gameinformation;

public class Game1Information extends IGameInformation {

	public Game1Information() {
		super("background_easy.png", 320, 480, 1024, 512, 60,
				800, 200);
	}

}
