package fishjoy.model.numberinformation;

public class Number8Information extends INumberInformation {

	public Number8Information() {
		super("N8.png");
		// TODO Auto-generated constructor stub
	}

}
