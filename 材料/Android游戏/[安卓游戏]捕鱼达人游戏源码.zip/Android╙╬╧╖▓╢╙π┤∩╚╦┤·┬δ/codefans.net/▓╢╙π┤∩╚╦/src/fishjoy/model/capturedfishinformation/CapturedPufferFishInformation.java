package fishjoy.model.capturedfishinformation;

public class CapturedPufferFishInformation extends ICapturedFishInformation {

	public CapturedPufferFishInformation() {
		super("pufferfish_2.png", 52,31, 128, 256, 1, 5,0);
		// TODO Auto-generated constructor stub
	}

}
