package fishjoy.model.numberinformation;

public class Number9Information extends INumberInformation {

	public Number9Information() {
		super("N9.png");
		// TODO Auto-generated constructor stub
	}

}
