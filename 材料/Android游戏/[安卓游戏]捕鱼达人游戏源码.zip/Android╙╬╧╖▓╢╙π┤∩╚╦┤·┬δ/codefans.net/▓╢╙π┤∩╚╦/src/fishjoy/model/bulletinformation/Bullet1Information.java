package fishjoy.model.bulletinformation;

import fishjoy.model.netinformation.Net1Information;

public class Bullet1Information extends IBulletInformation {

	public Bullet1Information() {
		super("B1.png",15,21,16,32, new Net1Information(), 110, 370, 150);
		// TODO Auto-generated constructor stub
	}

}
