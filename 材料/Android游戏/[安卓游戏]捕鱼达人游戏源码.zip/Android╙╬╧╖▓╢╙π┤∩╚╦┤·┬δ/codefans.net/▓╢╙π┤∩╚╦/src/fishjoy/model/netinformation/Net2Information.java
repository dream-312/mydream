package fishjoy.model.netinformation;

public class Net2Information extends INetInformation {

	public Net2Information() {
		super("net2.png", 172, 800, 256, 1024);
		// TODO Auto-generated constructor stub
	}

}
