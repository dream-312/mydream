package fishjoy.model.scoreInformation;

public class Score3Information extends IScoreInformation {

	public Score3Information() {
		super("30.png", 71, 30,128, 256, 1, 6);
		// TODO Auto-generated constructor stub
	}

}
