package fishjoy.model.numberinformation;

public class Number7Information extends INumberInformation {

	public Number7Information() {
		super("N7.png");
		// TODO Auto-generated constructor stub
	}

}
