/** Automatically generated file. DO NOT MODIFY */
package whu.iss.sric.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}