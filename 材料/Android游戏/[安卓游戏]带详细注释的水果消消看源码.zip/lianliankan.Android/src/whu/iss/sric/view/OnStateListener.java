package whu.iss.sric.view;


public interface OnStateListener{
	public void OnStateChanged(int StateMode);
}
