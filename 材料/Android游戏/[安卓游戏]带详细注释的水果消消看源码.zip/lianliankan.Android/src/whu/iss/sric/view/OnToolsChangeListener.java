package whu.iss.sric.view;


public interface OnToolsChangeListener{
	public void onRefreshChanged(int count);
	public void onTipChanged(int count);
}
