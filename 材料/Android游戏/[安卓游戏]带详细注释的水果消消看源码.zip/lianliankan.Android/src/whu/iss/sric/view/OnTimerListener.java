package whu.iss.sric.view;


public interface OnTimerListener{
	public void onTimer(int leftTime);
}
